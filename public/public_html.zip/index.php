<?php
$url='controller.php';
echo '<META HTTP-EQUIV=REFRESH CONTENT="1; '.$url.'">';
?>
<!DOCTYPE html>
<html>
<head>
<title>Main</title>
</head>
<body>

<h1>This is a Page is being redirected</h1>

</body>
</html>
